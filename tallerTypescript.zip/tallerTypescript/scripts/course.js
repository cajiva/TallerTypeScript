var Course = /** @class */ (function () {
    function Course(name, professor, credits) {
        this.name = name;
        this.credits = credits;
        this.professor = professor;
    }
    return Course;
}());
export { Course };
